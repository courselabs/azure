To package the source ZIP file for Kudu deployment:

```
# from /src/rng/Numbers.Api-v1.1

zip -r ../rng-api-v1-1.zip . *
```


Reference: https://github.com/MicrosoftDocs/azure-docs/issues/24121